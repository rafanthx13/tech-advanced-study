https://devhints.io/bash

## Criando arquivo de bash

Getting started with bash scripting
To create a bash script file the file should have a extension of .sh for example script.sh .
It may require permission to run the file first let’s set up that:
In your terminal type this code 

Cria arquivo bash 
touch filename.sh

Habilita ser executado
````
chmod +x filename.sh .
````

Escreve no arquivo

````
#! /bin/bash

VALUE="bash"
echo "$VALUE, ${VALUES}"
````

ENtrada

````
read num1 num2
````
Da pra trabalhar com

+ leitura de arquiv
+ if
+ funçôes
+case



