HUGO
https://tableless.com.br/primeiros-passos-com-hugo/
https://code.tutsplus.com/pt/tutorials/make-creating-websites-fun-again-with-hugo-the-static-website-generator-written-in-go--cms-27319
thema escolhido
https://github.com/gyuha/hago | https://hugothemesfree.com/hago-a-minimal-hugo-theme/

temas bons
https://hugothemesfree.com/a-simple-hugo-theme-using-bootstrap-v4/
https://hugothemesfree.com/a-minimal-hugo-theme-made-with-bootstrap/