# Advance Study

Estudos d ecoisa pequenas que, nao rprecsai de um repo apra cada uma

Ex:
+ rpa
+ linux
+ docker
+ vi/nano
alteracao

Akashi4die_1301
