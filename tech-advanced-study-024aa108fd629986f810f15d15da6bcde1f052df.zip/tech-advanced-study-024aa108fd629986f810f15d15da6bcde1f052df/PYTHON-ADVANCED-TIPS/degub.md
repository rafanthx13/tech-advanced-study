https://towardsdatascience.com/debug-python-scripts-like-a-pro-78df2f3a9b05

## lib icecream : print melhorado para debug

pip install icecream
from icecream import ic

ao invez de dar 'print' use 'ic'. 'ic mostra o nome da variavel e seu valor isso faz com que se evite de fazer print('total', total) para ic(total)
