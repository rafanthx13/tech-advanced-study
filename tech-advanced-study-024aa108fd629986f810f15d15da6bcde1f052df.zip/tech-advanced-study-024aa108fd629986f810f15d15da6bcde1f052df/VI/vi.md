# Editor vi

https://www.vivaolinux.com.br/dica/VI-O-fantastico-editor-de-textos
https://elias.praciano.com/2016/11/o-basico-do-editor-vi/

É a origem do nano e vim

Olhas e nao alterar
vi -R nome-do-arquivo


## Acessar com vi

$ vi nome_do_arquivo.txt

## Açôes do modo de comando

Há dois modos no vi: o de comando e o de inserçâo
+ E VOCÊ ESTÁ NO MODO DE COMANDO, VOCE NAO VAI CONSEGUIR DIGITAR NADA, É UM INFENRO
+ ELe nao msotra se voc eestá no modo de comando ou de inserçao

COmandos para entra no modeo de insrçai
+ i : vai escrever aonde o cursos está
+ a : vai adicionar dados appos o curso
+ A : vai escrever no fim da linha
+ o

ESC: Sir do modo de inserção (IMPORANTE)
 
u = undo  last chance
U = undo all cnahges
dd: deleta linha
3dd? deleta 3 linhas
D: delete conteudo depois do seu curros

## Comandos para salvar arquivo

:w = salvar arquivo

:wq / Shist+zz para sair e salvar do editor

:q! sair sem salvar

## Navegar pelas malsditas linhas no modo de comando

k: up
j: down

h = left
l = right

ou usa as setas padrao

(AS SETSA PADRAO NO MODO DE INSERÇAO INSERE COISA)

## EM resumo, o que voce via fazer

+ Entra no arquivo, e naevga com as setas
+ Quando chegar no que quer inserire/altera clique i
+ Depois vá figitando
+ CLique ESC para sair e para uma nova linha 'o'
+ Salvar e sair :wq; sair sem salvar :q!

NAO USE AS SETS NO MODO DE INSERÇÃO, ELAS NAO FUNCIONAM



mv /var/lib/docker /media/rhavel/7A60E25D60E21F9D/Docker

