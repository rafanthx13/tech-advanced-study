

## Buscar no históricos comandos que usaram uma certa 'word'
history | grep docker
